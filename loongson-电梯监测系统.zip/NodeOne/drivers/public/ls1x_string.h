#ifndef _LS1X_STRING_H_
#define _LS1X_STRING_H_

#include "test.h"

int atoi1(char *s);
int atohex1(char *str);
int strlen1(const char *p);
int strcmp1(const char *s1, const char *s2);
int memcmp1(const void *cs, const void *ct, int count);

void itoa1(char chWord[], int Num);
void *memcpy1(void *s1, const void *s2, int n);
void *memset1(void *s, int c, int count);

char *strchr1(const char *s, char c);
char *strcat1(char *dst, const char *src);
char *strcpy1(char *dest, const char *src);
char *pstrstr1(const char *haystack, const char *needle);
int strncmp1(const char *s1, const char *s2, size_t n);

INT8U strstr1(const INT8U *str, const INT8U *sub_str, INT8U num);

#endif