#ifndef __HX711_H
#define __HX711_H	


// #include "stdio.h"
// #include "stdlib.h"
#include "string.h"

#include "ls1x.h"

#include "ls1x_gpio.h" 
#include "ls1x_latimer.h"
#include "../user/ls1c102/oled.h"


#define	HX711_SCK_PIN 	GPIO_PIN_5
#define	HX711_DOUT_PIN 	GPIO_PIN_4


#define	HX711_SCK_LOW		gpio_write_pin(HX711_SCK_PIN, 0);	
#define	HX711_SCK_HIGH	    gpio_write_pin(HX711_SCK_PIN, 1);
#define	HX711_SCK_IN		gpio_get_pin(HX711_SCK_PIN)
#define	HX711_DOUT_IN 	    gpio_get_pin(HX711_DOUT_PIN)



void GPIO_HX711_Init(void);
void GPIO_HX711_SCK_Out(void);
void GPIO_HX711_SCK_In(void);
unsigned long HX711_Read(void);
void Get_Maopi(void);
long Get_Weight(void);
#endif
