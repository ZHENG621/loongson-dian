#include "key.h"
#include "ls1x_latimer.h"
#include "ls1x_gpio.h"

void KEY_Init(void)
{
    gpio_set_direction(KEY1_PIN, GPIO_Mode_In);
    gpio_set_direction(KEY2_PIN, GPIO_Mode_In);
    gpio_set_direction(KEY3_PIN, GPIO_Mode_In);
    gpio_set_direction(KEY4_PIN, GPIO_Mode_In);
}
uint8_t KEY_Scan(void)
{
 uint8_t key_Flag = 0;
    if (!gpio_get_pin(KEY1_PIN))
    {
        delay_ms(10);
        if (!gpio_get_pin(KEY1_PIN))
            key_Flag = 1;
        // 绛夊緟鎸夐敭閲婃斁
        while (!gpio_get_pin(KEY1_PIN));
    }
    else if (!gpio_get_pin(KEY2_PIN))
    {
        delay_ms(10);
        if (!gpio_get_pin(KEY2_PIN))
            key_Flag = 2;
        // 绛夊緟鎸夐敭閲婃斁
        while (!gpio_get_pin(KEY2_PIN));
    }
    else if (!gpio_get_pin(KEY3_PIN))
    {
        delay_ms(10);
        if (!gpio_get_pin(KEY3_PIN))
            key_Flag = 3;
        // 绛夊緟鎸夐敭閲婃斁
        while (!gpio_get_pin(KEY3_PIN));
    }
    else if (!gpio_get_pin(KEY4_PIN))
    {
        delay_ms(10);
        if (!gpio_get_pin(KEY4_PIN))
            key_Flag = 4;
        // 绛夊緟鎸夐敭閲婃斁
        while (!gpio_get_pin(KEY4_PIN));
    }
    return key_Flag;
}
//uint8_t KEY_Scan(void)
//{
 //   uint8_t key_Flag = 0;
 //   if (!gpio_get_pin(KEY1_PIN))
 //   {
  //      delay_ms(10);
 //       if (!gpio_get_pin(KEY1_PIN))
 //           key_Flag = 1;
 //       // 等待按键释放
  //      while (!gpio_get_pin(KEY1_PIN));
  //  }
  //  else if (!gpio_get_pin(KEY2_PIN))
  //  {
  //      delay_ms(10);
  //      if (!gpio_get_pin(KEY2_PIN))
  ///          key_Flag = 2;
        // 等待按键释放
  //      while (!gpio_get_pin(KEY2_PIN));
  //  }
   // else if (!gpio_get_pin(KEY3_PIN))
  //  {
   //     delay_ms(10);
   //     if (!gpio_get_pin(KEY3_PIN))
   //         key_Flag = 3;
        // 等待按键释放
    //    while (!gpio_get_pin(KEY3_PIN));
   // }
   // else if (!gpio_get_pin(KEY4_PIN))
   // {
   //     delay_ms(10);
    //    if (!gpio_get_pin(KEY4_PIN))
    //        key_Flag = 4;
        // 等待按键释放
  //      while (!gpio_get_pin(KEY4_PIN));
  //  }
  //  return key_Flag;
//}
//uint8_t KEY_Check(void)
//{
//    if (!gpio_get_pin(KEY1_PIN))// 读取按键状态
//    { 
 //       return 1;
 //   }
 //   else if(!gpio_get_pin(KEY2_PIN))
 //   {
 //       return 2;
 //   }
 //   else if(!gpio_get_pin(KEY3_PIN))
 //   {
 //       return 3;
 //   }
 //   else if(!gpio_get_pin(KEY4_PIN))
 //   {
 //       return 4;
 //   }
 //   else
 //   {
 //       return 0;
 //  }
//}
