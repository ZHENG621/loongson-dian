#include "ls1x.h"
#include "ls1x_gpio.h"
#include "UserGpio.h"
#include "Config.h"
#include "ls1x_clock.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "led.h"
#include "key.h"
#include "BEEP.h"
#include "oled.h"
#include "oledpic.h"
#include "ZigBee.h"
#include "ls1c102_interrupt.h"
#include "iic.h"
#include "dht11.h"
#include "queue.h"
#include "hx711.h"
#include "ls1c102_adc.h"

#define LED 20
long  weight_object = 0;
char str[50];
static uint16_t temperature;
static uint16_t humidity;
uint8_t key_value = 0;
uint8_t received_data = 0;
uint8_t data[9];
uint8_t Read_Buffer[255]; // 设置接收缓冲数组
uint8_t Read_length;
uint8_t stick;


int main(int arg, char *args[])
{
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    OLED_Init();
    EnableInt(); // 开总中断
    // Uart1_init(9600);
    DL_LN3X_Init(DL_LN3X_NODE,CHANNEL,Network1_Id);//设置为主机（接收端），设置信道为0x12，网络地址为0x0003
    Queue_Init(&Circular_queue);
    BEEP_Init();
    
    DHT11_Init();                               // DHT11初始化  
    GPIO_HX711_Init();          //初始化
	Get_Maopi();                //去皮
    

    int mode=5;

    AFIO_RemapConfig(AFIOB, GPIO_Pin_16, 0);
    Adc_powerOn();
    Adc_open(ADC_CHANNEL_I6);

    while (1)
    {
       
        key_value=KEY_Scan();
        DHT11_Read_Data(&temperature, &humidity);
        weight_object = Get_Weight(); 
        stick =Adc_Measure(ADC_CHANNEL_I6);
        
         // 数据包整理
        data[0] = 0x02;
        data[1] = temperature / 256;
        data[2] = temperature % 256;
        data[3] = humidity / 256;
        data[4] = humidity % 256;
        data[5] = weight_object /256;
        data[6] = weight_object %256;
        data[7] = stick;
         
        delay_ms(222);
        DL_LN3X_Send(data, 9, ZIGBEE_RX_NODE); // 发送数据包、

        if (key_value==1)
        {
            mode=1;
        }
        if (key_value==2)
        {
            mode=2;
        }
        if (key_value==3)
        {
            mode=3;
        }
        if (key_value==4)
        {
            mode=4;
        }
      
        switch (mode)
        {
        case 1: 

            if (weight_object>100)
            {
                OLED_Show_Str(0, 6, "  已超重         ", 16);    // OLED显示界面
                 BEEP_ON;
                 delay_ms(500);
                 BEEP_OFF;
                 delay_ms(500);
            }
            weight_object = Get_Weight(); 
            OLED_Show_Str(0, 0, "  压力检测       ", 16); // OLED显示界面
            sprintf(str, "  重量: %d g       ", weight_object);
            OLED_Show_Str(0, 3, str, 16);    // OLED显示界面
            OLED_Show_Str(0, 6, "                ", 16);    // OLED显示界面
            
        break;
        case 2:
             OLED_Show_Str(5, 6, "              ", 16);    // OLED显示界面
            if (temperature>400)
            {
                OLED_Show_Str(0, 6, "  温度过高       ", 16);    // OLED显示界面
                
                 BEEP_ON;
                 delay_ms(500);
                 BEEP_OFF;
                 delay_ms(500);
                
            }
            
            DHT11_Read_Data(&temperature, &humidity);
             OLED_Show_Str(0, 0, "  温度检测       ", 16); // OLED显示界面
            sprintf(str, "  温度: %2d ℃      ", temperature / 10);
            OLED_Show_Str(0, 3, str, 16);    // OLED显示界面
            OLED_Show_Str(0, 6, "             ", 16);    // OLED显示界面
             
         break;
        case 3:
            OLED_Show_Str(5, 6, "              ", 16);    // OLED显示界面
            if (humidity>800)
            {
                OLED_Show_Str(0, 6, "  湿度过高       ", 16);    // OLED显示界面
              
                 BEEP_ON;
                 delay_ms(500);
                 BEEP_OFF;
                 delay_ms(500);
                
            }
            DHT11_Read_Data(&temperature, &humidity);
            OLED_Show_Str(0, 0, "  湿度检测       ", 16); // OLED显示界面
           sprintf(str, "  湿度: %2d %%RH    ", humidity / 10);
           OLED_Show_Str(0, 3, str, 16);    // OLED显示界面
          //  OLED_Show_Str(5, 6, "             ", 16);    // OLED显示界面
            break;
        case 4:
          if (stick >= 255)
            {
                OLED_Show_Str(0, 6, "  异常抖动       ", 16);
                BEEP_ON;
                delay_ms(500);
                BEEP_OFF;
                delay_ms(500);
            }
            OLED_Show_Str(0, 0, "  振动检测       ", 16);
            sprintf(str, "  振动值: %d          ", stick-95);
            OLED_Show_Str(0, 3, str, 16);
            OLED_Show_Str(0, 6, "                ", 16);
            break;

        case 5:
        OLED_Show_Str(0, 0, "面向适老需求的城", 16);    // OLED显示界面
        OLED_Show_Str(0, 3, "老旧小区户外电", 16);    // OLED显示界面
        OLED_Show_Str(0, 6, "梯运行监测系统", 16);    // OLED显示界面
            break;
        default:
            break;
        }

    }

    return 0;
}